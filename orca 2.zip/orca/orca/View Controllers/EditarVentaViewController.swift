//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class EditarVentaViewController: UIViewController {

    var todos = [[String:AnyObject]]()
    var detalles = [[String:AnyObject]]()
    var producto = [[String:AnyObject]]()
    var clientes = [[String:AnyObject]]()
    var productos = [[String:AnyObject]]()
    var idVenta = Int()
    var idCliente = Int()
    var idProducto = Int()
    var apiurl = "https://groovy-momentum-253317.appspot.com/ventas/"
    var urlProductos = "https://groovy-momentum-253317.appspot.com/productos/"
    let urlClientes = "https://groovy-momentum-253317.appspot.com/clientes/"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""

    @IBOutlet weak var cliente: UIPickerView!
    @IBOutlet weak var fecha: UIDatePicker!
    @IBOutlet weak var productoPicker: UIPickerView!
    @IBOutlet weak var cantidad: UITextField!
    @IBOutlet weak var precio: UITextField!
    
    @IBAction func load(url: String) {
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        let params = ["accessKey":"123"]
        AF.request(url,parameters: params,headers: header).responseJSON { (responseData) -> Void in
            if((responseData.value) != nil) {
                let swiftyJsonVar = JSON([responseData.value!])
                if let resData = swiftyJsonVar.arrayObject {
                    self.todos = resData as! [[String:AnyObject]]
                    //Cargar cliente
                    self.idCliente = self.todos[0]["idCliente"] as! Int
                    self.load(tag: 0)
                    //Cargar Fecha
                    
                    let date = self.todos[0]["updatedAt"] as! String
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
                    guard let dateF = dateFormatter.date(from: String(date)) else {
                        fatalError()
                    }
                    self.fecha.date = dateF
                    
                    let subJson = JSON(self.todos[0]["detalle"] as Any)
                    if let detalle = subJson.arrayObject{
                        self.detalles = detalle as! [[String:AnyObject]]
                    }
                    if(self.detalles.count != 0){
                        //Get[id] Producto para nombre de producto
                        self.idProducto = self.detalles[0]["idProducto"] as! Int
                        self.load(tag: 4)
                        //Cargar cantidad y precio
                        self.cantidad.text = String(self.detalles[0]["cantidad"] as! Int)
                        self.precio.text = String(self.detalles[0]["precio"] as! Float)
                    AF.request("\(self.urlProductos)\(String(self.idProducto))",parameters: params,headers: header).responseJSON { (response) -> Void in
                            if((response.value) != nil) {
                                let jsonVar = JSON([response.value!])
                                if let result = jsonVar.arrayObject {
                                    self.producto = result as! [[String:AnyObject]]
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func load(tag:Int) {
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        let params = ["accessKey":"123"]
        var url = "";
        if tag == 4{
            url = urlProductos
        }
        else{
            url = urlClientes
        }
        AF.request(url,parameters: params,headers: header).responseJSON { (responseData) -> Void in
            if((responseData.value) != nil) {
                let swiftyJsonVar = JSON(responseData.value!)
                if let resData = swiftyJsonVar.arrayObject {
                    if tag == 4{
                        self.productos = resData as! [[String:AnyObject]]
                    }
                    else if tag == 0{
                        self.clientes = resData as! [[String:AnyObject]]
                    }
                }
                if self.productos.count > 0{
                    DispatchQueue.main.async{
                        self.productoPicker.reloadComponent(0)
                    }
                }
                if self.clientes.count > 0{
                    DispatchQueue.main.async{
                        self.cliente.selectRow(self.idCliente-1, inComponent: 0, animated: true)
                        self.productoPicker.selectRow(self.idProducto-2 > 0 ? self.idProducto-2 : self.idProducto-1, inComponent: 0, animated: true)
                        self.cliente.reloadComponent(0)
                    }
                }
            }
        }
    }
    
    @IBAction func registrar(_ sender: Any) {
        let indexProducto = productoPicker.selectedRow(inComponent: 0)
        let indexCliente = cliente.selectedRow(inComponent: 0)
        let idProducto = productos[indexProducto]["idProducto"] as! Int
        let idCliente = clientes[indexCliente]["idCliente"] as! Int
        
        let cantidadstr = cantidad.text!.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let str = precio.text!.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        
        
        let start = str.index(str.startIndex, offsetBy: 0)
        let end = str.index(str.endIndex, offsetBy: 0)
        let range = start..<end

        let mySubstring = str[range]
        
        let date = Date()
        let format = DateFormatter()
        format.dateFormat = "yyyy-MM-dd"
        let formattedDate = format.string(from: date)
        let params: [String: Any] = [
            "idCliente": idCliente,
            "fecha": formattedDate,
            "disponible": 2,
            "detallesventa": [
                [
                    "idVenta": idVenta,
                    "id": detalles[0]["id"] as! Int,
                    "idProducto" : idProducto,
                    "cantidad": Int(cantidadstr)!,
                    "precio": Float(mySubstring)!
                ]
            ],
            "detallesVentaEliminados":[]
        ]
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        AF.request("https://groovy-momentum-253317.appspot.com/ventas/\(idVenta)", method: .put, parameters: params,encoding: JSONEncoding.default,headers:header).responseJSON  { response in
            if let json = response.value {
                print("JSON: \(json)") // serialized json response after post
            }
            if response.response?.statusCode == 200{
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.cliente.delegate = self
        self.cliente.dataSource = self
        self.productoPicker.delegate = self
        self.productoPicker.dataSource = self
        
        apiurl = "\(apiurl)\(idVenta)"
        load(url: apiurl)
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
}

extension EditarVentaViewController:UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 4{
            return productos.count
        }
        else{
            return clientes.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 4{
            return productos[row]["nombre"] as? String
        }
        else{
            return clientes[row]["nombre"] as? String
        }
    }
}
