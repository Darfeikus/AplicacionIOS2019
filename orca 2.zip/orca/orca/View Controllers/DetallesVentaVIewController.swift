//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class DetallesVentaViewController: UIViewController {

    var venta = [[String:AnyObject]]()
    var unavailable = [[String:AnyObject]]()
    var detalles = [[String:AnyObject]]()
    var productos = [[String:AnyObject]]()
    var clientes = [[String:AnyObject]]()
    var idEliminados = [Int]()
    var idVenta = Int()
    var idCliente = 0
    var apiurl = "https://groovy-momentum-253317.appspot.com/ventas/"
    var urlProducto = "https://groovy-momentum-253317.appspot.com/productos/"
    var urlClientes = "https://groovy-momentum-253317.appspot.com/clientes/"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    var modify = 0
    var row = 0
    
    @IBOutlet weak var cliente: UIPickerView!
    @IBOutlet weak var totalVenta: UILabel!
    @IBOutlet weak var fecha: UILabel!
    @IBOutlet weak var fechaModificacion: UILabel!
    @IBOutlet weak var producto: UITableView!
    
    @IBAction func toAgregar(_ sender: Any) {
        performSegue(withIdentifier: "toAgregar", sender: self)
    }
    
    @IBAction func pop(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        reload(self)
        self.modify = 0
    }
    
    @IBAction func reload(_ sender: Any) {
        producto.reloadData()
        var sum: Float = 0
        for z in productos {
            sum += Float(truncating: z["precio"]! as! NSNumber)
        }
        totalVenta.text = String(sum)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC = segue.destination as! AgregarProductoViewController
        destinationVC.misProductos = self.productos
        destinationVC.edit = 1
        destinationVC.row = self.row
        destinationVC.modify = self.modify
    }
    
    @IBAction func registrar(_ sender: Any) {
        let indexCliente = cliente.selectedRow(inComponent: 0)
        let idCliente = clientes[indexCliente]["idCliente"] as! Int
        let date = Date()
        let format = DateFormatter()
        format.dateFormat = "yyyy-MM-dd"
        let formattedDate = format.string(from: date)
        
        if(productos.count>0){
            for n in 0...productos.count-1{
                productos[n]["idVenta"] = idVenta as AnyObject
            }
        }
        for curr in detalles{
            if productos.count > 0{
                for n in 0...productos.count-1{
                    if Int(truncating: curr["idProducto"] as! NSNumber) == Int(truncating: productos[n]["idProducto"] as! NSNumber){
                        productos[n]["id"] = curr["id"]
                        break
                    }
                }
            }
        }
        
        let params: [String: Any] = [
            "idCliente": idCliente as Any,
            "fecha": formattedDate,
            "disponible": 2,
            "detallesventa": productos,
            "detallesVentaEliminados": idEliminados
        ]
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        AF.request("https://groovy-momentum-253317.appspot.com/ventas/\(idVenta)", method: .put, parameters: params,encoding: JSONEncoding.default,headers:header).responseJSON  { response in
            if let json = response.value {
                print("JSON: \(json)")
            }
            if response.response?.statusCode == 200{
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.producto.delegate = self
        self.producto.dataSource = self
        self.cliente.delegate = self
        self.cliente.dataSource = self
        apiurl = "\(apiurl)\(idVenta)"
        load(url: apiurl)
    }
    
    @IBAction func load(url: String) {
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        let params = ["accessKey":"123"]
        AF.request(url,parameters: params,headers: header
        ).responseJSON { (responseData) -> Void in
            if((responseData.value) != nil) {
                let swiftyJsonVar = JSON([responseData.value!])
                if let resData = swiftyJsonVar.arrayObject {
                    self.venta = resData as! [[String:AnyObject]]
                    AF.request(self.urlClientes,parameters: params,headers: header).responseJSON { (responseData) -> Void in
                        if((responseData.value) != nil) {
                            let swiftyJsonVar = JSON(responseData.value!)
                            if let resData = swiftyJsonVar.arrayObject {
                                self.clientes = resData as! [[String:AnyObject]]
                                //Filter data
                                for item in self.clientes {
                                    if Int(truncating: item["disponible"] as! NSNumber) != 2{
                                        self.unavailable.append(item)
                                    }
                                    
                                }
                                for item in self.unavailable{
                                    let index = self.clientes.firstIndex(where: { dictionary in
                                      let value = dictionary["idCliente"] as! Int
                                      return value == item["idCliente"] as! Int
                                    })
                                    if index != nil {
                                        self.clientes.remove(at: index!)
                                    }
                                    DispatchQueue.main.async{
                                        self.cliente.reloadAllComponents()
                                    }
                                }
                            }
                            DispatchQueue.main.async{
                                self.cliente.reloadAllComponents()
                                self.cliente.selectRow(self.idCliente-1, inComponent: 0, animated: true)
                            }
                        }
                    }
                    //Total
                    self.totalVenta.text = "\(Float(truncating: self.venta[0]["total"] as! NSNumber))"
                    //Fechas
                    var date = self.venta[0]["fecha"] as! String
                    var index = date.index(date.startIndex,offsetBy: 10)
                    var sub = date.prefix(upTo: index)
                    self.fecha.text = String(sub)
                    date = self.venta[0]["updatedAt"] as! String
                    index = date.index(date.startIndex,offsetBy: 10)
                    sub = date.prefix(upTo: index)
                    self.fechaModificacion.text = String(sub)
                    //Obtener Array de Productos
                    let subJson = JSON(self.venta[0]["detalle"] as Any)
                    if let detalle = subJson.arrayObject{
                        self.detalles = detalle as! [[String:AnyObject]]
                    }
                    for detalle in self.detalles {
                        let idProducto = Int(truncating: detalle["idProducto"] as! NSNumber)
                        AF.request("\(self.urlProducto)\(idProducto)",parameters: params,headers: header).responseJSON { (response) -> Void in
                             if((response.value) != nil) {
                                let jsonVar = JSON([response.value!])
                                if let result = jsonVar.arrayObject {
                                    self.productos.append(result[0] as! [String:AnyObject])
                                    self.productos[self.productos.count-1]["precio"] = detalle["precio"]
                                    self.productos[self.productos.count-1]["cantidad"] = detalle["cantidad"]
                                    self.producto.reloadData()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

extension DetallesVentaViewController:UITableViewDataSource,UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath)
        cell.textLabel?.text = productos[indexPath.row]["nombre"] as? String
        let cantidad = Int(truncating: productos[indexPath.row]["cantidad"]! as! NSNumber)
        let precio = Float(truncating: productos[indexPath.row]["precio"]! as! NSNumber)
        cell.detailTextLabel?.text = "Cantidad: \(cantidad)   Precio: $\(precio)"
        return cell
     }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return productos.count
     }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCell.EditingStyle.delete{
            let c = productos[indexPath.row].count
            if c>4{
                var index = 0
                for f in detalles {
                    if f["idProducto"] as! Int == productos[indexPath.row]["idProducto"] as! Int{
                        idEliminados.append(f["id"] as! Int)
                        detalles.remove(at: index)
                        break;
                    }
                    index += 1
                }
            }
            productos.remove(at: indexPath.row)
            producto.deleteRows(at: [indexPath], with: .automatic)
            reload(self)
        }
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let editAction = UIContextualAction(style: .normal, title: "Editar"){ (action,view,completionHandler) in
            self.modify = 1;
            self.row = indexPath.row
            self.performSegue(withIdentifier: "toAgregar", sender: self)
            completionHandler(true)
        }
        editAction.backgroundColor = UIColor.blue
        return UISwipeActionsConfiguration(actions: [editAction])
    }
}

extension DetallesVentaViewController:UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return clientes.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return clientes[row]["nombre"] as? String
    }
}
