//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class InventarioViewController: UIViewController {

    var todos = [[String:AnyObject]]()
    var unavailable = [[String:AnyObject]]()
    var apiurl = "https://groovy-momentum-253317.appspot.com/productos"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    var nombres = String()
    var descripcions = String()
    var cantidads = String()
    var utilidads = String()
    var creados = String()
    var updates = String()
    var precios = String()
    var costos = String()

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var fechaInicio: UIDatePicker!
    @IBOutlet weak var fechaFinal: UIDatePicker!
    
    override func viewWillAppear(_ animated: Bool) {
        load(self)
    }
    
    @IBAction func load(_ sender: Any) {
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        let params = ["accessKey":"123"]
        self.unavailable.removeAll()
        self.todos.removeAll()
        AF.request(apiurl,parameters: params,headers: header).responseJSON { (responseData) -> Void in
            if((responseData.value) != nil) {
                let swiftyJsonVar = JSON(responseData.value!)
                if let resData = swiftyJsonVar.arrayObject {
                    self.todos = resData as! [[String:AnyObject]]
                    //Filter data
                    for item in self.todos {
                        let date = item["createdAt"] as! String
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        let currDate = dateFormatter.date(from:String(date.prefix(upTo: date.index(date.startIndex,offsetBy: 10))))!
                        if currDate < self.fechaInicio.date || currDate > self.fechaFinal.date {
                            self.unavailable.append(item)
                        }
                        
                    }
                    for item in self.unavailable{
                        let index = self.todos.firstIndex(where: { dictionary in
                          let value = dictionary["idProducto"] as! Int
                          return value == item["idProducto"] as! Int
                        })
                        if index != nil {
                            self.todos.remove(at: index!)
                        }
                    }
                }
                DispatchQueue.main.async{
                    self.tableView.reloadData()
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationVC = segue.destination as! DetallesProductoViewController
        destinationVC.nombres = self.nombres
        destinationVC.descripcions = self.descripcions
        destinationVC.cantidads = self.cantidads
        destinationVC.utilidads = self.utilidads
        destinationVC.creados = self.creados
        destinationVC.updates = self.updates
        destinationVC.precios = self.precios
        destinationVC.costos = self.costos
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        load(self)
    }
    
    @IBAction func toRegistroProducto(_ sender: Any) {
        self.performSegue(withIdentifier: "toRegistroProducto" , sender: self)
    }
    @IBAction func nuevaCategoria(_ sender: Any) {
        self.performSegue(withIdentifier: "inventarioToTipoProducto" , sender: self)
    }
}

extension InventarioViewController:UITableViewDataSource, UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let editAction = UIContextualAction(style: .normal, title: "Detalles"){ (action,view,completionHandler) in
            let unidad = self.todos[indexPath.row]["unidad"]?["unidad"] as! String
            self.nombres = self.todos[indexPath.row]["nombre"] as! String
            self.descripcions = self.todos[indexPath.row]["descripcion"] as! String
            self.cantidads = "\(self.todos[indexPath.row]["cantidad"] as? Int ?? 0) \(unidad)"
            self.utilidads = "$\(self.todos[indexPath.row]["utilidad"] as? Int ?? 0)"
            self.precios = "$\(self.todos[indexPath.row]["precio"] as? Int ?? 0)"
            self.costos = "$\(self.todos[indexPath.row]["costo"] as? Int ?? 0)"
            self.creados = self.todos[indexPath.row]["createdAt"] as! String
            self.updates = self.todos[indexPath.row]["updatedAt"] as! String
            self.creados = String(self.creados.prefix(10))
            self.updates = String(self.updates.prefix(10))
            self.performSegue(withIdentifier: "toDetallesProducto", sender: self)
            completionHandler(true)
        }
        editAction.backgroundColor = UIColor.blue
        return UISwipeActionsConfiguration(actions: [editAction])
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let total = todos[indexPath.row]["cantidad"] as! Int
        let unidad = todos[indexPath.row]["unidad"]?["unidad"] as! String
        
        let date = todos[indexPath.row]["createdAt"] as! String
        let index = date.index(date.startIndex,offsetBy: 10)
        let sub = date.prefix(upTo: index)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currDate = dateFormatter.date(from:String(sub))!
        
        let inTimeFrame = currDate >= fechaInicio.date && currDate <= fechaFinal.date
        
        let disp = todos[indexPath.row]["disponible"] as! Int
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath)
        
        if disp==2 && inTimeFrame{
            cell.textLabel?.text = todos[indexPath.row]["nombre"] as? String
            cell.detailTextLabel?.text = "Cantidad: \(String(total)) \(String(unidad)) Fecha: \(String(sub))"
        }
        else{
            cell.isHidden = true
        }
        return cell
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return todos.count
     }
    
    
}
