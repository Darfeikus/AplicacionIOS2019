//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class DetallesProductoViewController: UIViewController {

    var nombres = String()
    var descripcions = String()
    var cantidads = String()
    var utilidads = String()
    var creados = String()
    var updates = String()
    var precios = String()
    var costos = String()

    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var descripcion: UILabel!
    @IBOutlet weak var cantidad: UILabel!
    @IBOutlet weak var utilidad: UILabel!
    @IBOutlet weak var creado: UILabel!
    @IBOutlet weak var update: UILabel!
    @IBOutlet weak var precio: UILabel!
    @IBOutlet weak var costo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nombre.text = nombres
        descripcion.text = descripcions
        cantidad.text = cantidads
        utilidad.text = utilidads
        creado.text = creados
        update.text = updates
        precio.text = precios
        costo.text = costos
    }
    
}
