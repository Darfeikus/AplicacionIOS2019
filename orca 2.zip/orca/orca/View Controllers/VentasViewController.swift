//
//  FirstViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class VentasViewController: UIViewController {

    var todos = [[String:AnyObject]]()
    var apiurl = "https://groovy-momentum-253317.appspot.com/ventas"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    var unavailable = [[String:AnyObject]]()
    var indexRow = Int()
    
    @IBOutlet var tableView: UITableView! = UITableView()
    @IBOutlet var fechaInicio: UIDatePicker! = UIDatePicker()
    @IBOutlet var fechaFinal: UIDatePicker! = UIDatePicker()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? DetallesVentaViewController {
            let idVenta = todos[indexRow]["idVenta"] as! Int
            destinationVC.idVenta = idVenta
            destinationVC.idCliente = todos[indexRow]["idCliente"] as! Int
        }
        else{
            return
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        toApp(self)
    }
    
    @IBAction func load(isTest: Bool,completionHandler: @escaping(_ status:Bool)->Void) {

        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        
        let params = ["accessKey":"123"]
        
        self.unavailable.removeAll()
        
        self.todos.removeAll()
        
        AF.request(apiurl,parameters: params,headers: header).responseJSON { (responseData) -> Void in
        
            if((responseData.value) != nil) {
            
                let swiftyJsonVar = JSON(responseData.value!)
                
                if let resData = swiftyJsonVar.arrayObject {
                
                    self.todos = resData as! [[String:AnyObject]]
                    
                    //Filter data
                    
                    for item in self.todos {
                    
                        let date = item["fecha"] as! String
                        
                        let dateFormatter = DateFormatter()
                        
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        let currDate = dateFormatter.date(from:String(date.prefix(upTo: date.index(date.startIndex,offsetBy: 10))))!
                        
                        if currDate < self.fechaInicio.date || currDate > self.fechaFinal.date || Int(truncating: item["disponible"] as! NSNumber) != 2{
                        
                            self.unavailable.append(item)
                            
                        }
                        
                        
                        
                    }
                    
                    for item in self.unavailable{
                        let index = self.todos.firstIndex(where: { dictionary in
                          let value = dictionary["idVenta"] as! Int
                          return value == item["idVenta"] as! Int
                        })
                        if index != nil {
                            self.todos.remove(at: index!)
                        }
                        
                    }
                    
                }
                
                CATransaction.begin()
                
                CATransaction.setCompletionBlock {
                
                    completionHandler(true)
                    
                }
                
                self.tableView.reloadData()
                
                CATransaction.commit()
                
            }
            
        }
        
    }

    
    @IBAction func toCliente(_ sender: Any) {
        performSegue(withIdentifier: "toRegistrarCliente", sender: self)
    }
    @IBAction func toVenta(_ sender: Any) {
        performSegue(withIdentifier: "toRegistroVenta", sender: self)
    }
    
    @IBAction func toApp(_ sender: Any) {
        load(isTest: false){ (handler: Bool) in
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        
        tableView.delegate = self
        
        toApp(self)
    }
    
}
extension VentasViewController:UITableViewDataSource, UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let date = todos[indexPath.row]["fecha"] as! String
        let index = date.index(date.startIndex,offsetBy: 10)
        let sub = date.prefix(upTo: index)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currDate = dateFormatter.date(from:String(sub))!
        let inTimeFrame = currDate >= fechaInicio.date && currDate <= fechaFinal.date
        let disp = todos[indexPath.row]["disponible"] as! Int
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath)
        
        if disp==2 && inTimeFrame{
            cell.textLabel?.text = todos[indexPath.row]["cliente"]?["nombre"] as? String
            cell.detailTextLabel?.text = "$\(Float(truncating: todos[indexPath.row]["total"] as! NSNumber))\tFecha:\(sub)"
        }
        else{
            cell.isHidden = true
        }
        return cell
     }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return todos.count
     }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let editAction = UIContextualAction(style: .normal, title: "Detalles"){ (action,view,completionHandler) in
            self.indexRow = indexPath.row
            self.performSegue(withIdentifier: "toDetalles", sender: self)
            completionHandler(true)
        }
        editAction.backgroundColor = UIColor.blue
        return UISwipeActionsConfiguration(actions: [editAction])
    }
}
