//
//  orcaTests.swift
//  orcaTests
//
//  Created by Oscar Barbosa Aquino on 28/11/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import XCTest

@testable import orca
@testable import Alamofire
@testable import SwiftyJSON
@testable import Charts

class orcaTests: XCTestCase {

    func testInicioSuccess(){
        let clas = IniciarSesionViewController()
        XCTAssertNotNil(clas.viewDidLoad())
        XCTAssertNotNil(clas.dismissKeyboard())
        clas.usuario.text = "darfeikus"
        clas.password.text = "123"
        let e = self.expectation(description: "Login")
        clas.toAplicacion(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testInicioFailure(){
        let clas = IniciarSesionViewController()
        clas.usuario.text = "x"
        clas.password.text = "x"
        let e = self.expectation(description: "Login")
        clas.toAplicacion(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }

    func testRegistroSuccess(){
        let clas = RegistrarUsuarioViewController()
        clas.usuario.text = ""
        clas.contrasena.text = ""
        clas.nombre.text = ""
        clas.apellidos.text = ""
        XCTAssertNotNil(clas.viewDidLoad())
        XCTAssertNotNil(clas.dismissKeyboard())
        let e = self.expectation(description: "Login")
        clas.toAplicacion(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testRegistroFailure(){
        let clas = RegistrarUsuarioViewController()
        clas.apiurl = ""
        let e = self.expectation(description: "Login")
        clas.toAplicacion(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testHome(){
        let clas = HomeViewController()
        XCTAssertNotNil(clas.viewDidLoad())
    }
    
    func testAjustes(){
        let clas = AjustesViewController()
        XCTAssertNotNil(clas.viewDidLoad())
    }
    
    func testVenta(){
        let clas = VentasViewController()
        XCTAssertNotNil(clas.viewDidLoad())
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testCompra(){
        let clas = ComprasViewController()
        XCTAssertNotNil(clas.viewDidLoad())
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testProveedores(){
        let clas = ProveedoresViewController()
        XCTAssertNotNil(clas.viewDidLoad())
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testClientes(){
        let clas = ClientesViewController()
        XCTAssertNotNil(clas.viewDidLoad())
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testAgregarProducto(){
        let clas = AgregarProductoViewController()
        
        clas.modify=0;
        
        XCTAssertNotNil(clas.viewDidLoad())
        XCTAssertNotNil(clas.dismissKeyboard())
        
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testAgregarProductoPreload(){
        let clas = AgregarProductoViewController()
        clas.modify=1
        clas.cantidad.text = "3"
        clas.precio.text = "2"
        clas.total.text = "15"
        clas.row = 0
        let misProductos :[[String:AnyObject]] = [[
            "idProducto": 1 as AnyObject,
            "nombre": "papa" as AnyObject,
            "cantidad": 3 as AnyObject,
            "precio": 10 as AnyObject
        ]]
        clas.misProductos = misProductos
        clas.productos = misProductos
        let e = self.expectation(description: "Login")
        clas.loadValues(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        clas.registrar(self)
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testAgregarProductoCompra(){
        let clas = AgregarProductoCompraViewController()
        
        clas.modify=0;
        
        XCTAssertNotNil(clas.viewDidLoad())
        XCTAssertNotNil(clas.dismissKeyboard())
        
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testAgregarProductoCompraPreload(){
        let clas = AgregarProductoCompraViewController()
        clas.modify=1
        clas.cantidad.text = "3"
        clas.precio.text = "2"
        clas.total.text = "15"
        clas.row = 0
        let misProductos :[[String:AnyObject]] = [[
            "idProducto": 1 as AnyObject,
            "nombre": "papa" as AnyObject,
            "cantidad": 3 as AnyObject,
            "precio": 10 as AnyObject
        ]]
        clas.misProductos = misProductos
        clas.productos = misProductos
        let e = self.expectation(description: "Login")
        clas.loadValues(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        clas.registrar(self)
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testRegistrarProveedor(){
        let clas = RegistrarProveedorViewController()
        
        XCTAssertNotNil(clas.viewDidLoad())
        XCTAssertNotNil(clas.dismissKeyboard())
        
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        
        clas.nombre.text = "Pedro"
        clas.direccion.text = "San Pedro Monterrey"
        clas.telefono.text = "0"
        clas.telefono2.text = "0"
        
        clas.registrarProveedor(isTest: true)
        
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testRegistrarCliente(){
        let clas = RegistrarClienteViewController()
        
        XCTAssertNotNil(clas.viewDidLoad())
        XCTAssertNotNil(clas.dismissKeyboard())
        
        let e = self.expectation(description: "Login")
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        
        clas.nombre.text = "Pedro"
        clas.direccion.text = "San Pedro Monterrey"
        clas.telefono.text = "0"
        clas.telefono2.text = "0"
        
        clas.registrarCliente(isTest: true)
        
        waitForExpectations(timeout: 5, handler: nil)
    }
 
    func testDetallesCliente(){
        let clas = DetallesClienteViewController()
        clas.nombres = "0"
        clas.direccions = "0"
        clas.telefono1s = "0"
        clas.telefono2s = "0"
        clas.creados = "0"
        clas.updates = "0"
        XCTAssertNotNil(clas.viewDidLoad())
    }
    
    func testDetallesProducto(){
        let clas = DetallesProductoViewController()
        clas.nombre.text = "0"
        clas.descripcion.text = "0"
        clas.cantidad.text = "0"
        clas.utilidad.text = "0"
        clas.creado.text = "0"
        clas.update.text = "0"
        clas.precio.text = "0"
        clas.costo.text =  "0"
        XCTAssertNotNil(clas.viewDidLoad())
    }
    
    func testDetallesVenta(){
        let clas = DetallesVentaViewController()
        clas.idVenta = 1
        XCTAssertNotNil(clas.viewDidLoad())
        let e = self.expectation(description: "Venta")
        
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testDetallesVentaRegistro(){
        let clas = DetallesVentaViewController()
        clas.idVenta = 0
        clas.productos = [
            [
                "idProducto": 0 as AnyObject,
                "idVenta" : 0 as AnyObject,
                "id" : 0 as AnyObject
            ]
        ]
        clas.detalles = [
            [
                "idProducto": -1 as AnyObject,
            ]
        ]
        let e = self.expectation(description: "Venta")
        
        clas.registrar(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        
        waitForExpectations(timeout: 5, handler: nil)
    }

    func testReloadVenta(){
        let clas = DetallesVentaViewController()
        clas.productos = [
            [
                "precio": 0 as AnyObject,
            ]
        ]
        clas.reload(clas)
    }
    
    func testDetallesCompras(){
        let clas = DetallesCompraViewController()
        clas.idVenta = 1
        XCTAssertNotNil(clas.viewDidLoad())
        let e = self.expectation(description: "Compra")
        
        clas.load(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        waitForExpectations(timeout: 5, handler: nil)
    }
    
    func testDetallesCompraRegistro(){
        let clas = DetallesCompraViewController()
        clas.idVenta = 0
        clas.productos = [
            [
                "idProducto": 0 as AnyObject,
                "idCliente" : 0 as AnyObject,
                "id" : 0 as AnyObject
            ]
        ]
        clas.detalles = [
            [
                "idProducto": -1 as AnyObject,
            ]
        ]
        let e = self.expectation(description: "Venta")
        
        clas.registrar(isTest: true){ (handler: Bool) in
            if handler{
                XCTAssertTrue(true)
                e.fulfill()
            }
        }
        
        waitForExpectations(timeout: 5, handler: nil)
    }

    func testReloadCompra(){
        let clas = DetallesCompraViewController()
        clas.productos = [
            [
                "precio": 0 as AnyObject,
            ]
        ]
        clas.reload(clas)
    }
}
