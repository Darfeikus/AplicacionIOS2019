//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class RegistrarProveedorViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource {
    
    var proveedores = [[String:AnyObject]]()
    var unavailable = [[String:AnyObject]]()

    var urlCategoriaProveedores = "https://groovy-momentum-253317.appspot.com/categoriasproveedor/"
    var urlProveedores = "https://groovy-momentum-253317.appspot.com/proveedores/"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    
    @IBOutlet var nombre: UITextField! = UITextField()
    @IBOutlet var direccion: UITextField! = UITextField()
    @IBOutlet var telefono: UITextField! = UITextField()
    @IBOutlet var telefono2: UITextField! = UITextField()
    @IBOutlet var proveedor: UIPickerView! = UIPickerView()
    
    @IBAction func toRegistrarCompra(_ sender: Any) {
        performSegue(withIdentifier: "toRegistrarCompra", sender: self)
    }

    @IBAction func toHome(_ sender: Any) {self.navigationController?.popViewController(animated: true)}
    
    @IBAction func load(isTest: Bool,completionHandler: @escaping(_ status:Bool)->Void) {

        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]

        let params = ["accessKey":"123"]

        AF.request(urlCategoriaProveedores,parameters: params,headers: header).responseJSON { (responseData) -> Void in

            if((responseData.value) != nil) {

                let swiftyJsonVar = JSON(responseData.value!)

                if let resData = swiftyJsonVar.arrayObject {

                    self.proveedores = resData as! [[String:AnyObject]]

                    for item in self.proveedores {

                        if Int(truncating: item["disponible"] as! NSNumber) != 2{

                            self.unavailable.append(item)

                        }

                        

                    }

                    for item in self.unavailable{
                        let index = self.proveedores.firstIndex(where: { dictionary in
                          let value = dictionary["idProveedor"] as! Int
                          return value == item["idProveedor"] as! Int
                        })
                        if index != nil {
                            self.proveedores.remove(at: index!)
                        }
                        DispatchQueue.main.async{ self.proveedor.reloadAllComponents()
                        }
                    }
                }

                DispatchQueue.main.async{

                    self.proveedor.reloadAllComponents()

                    completionHandler(true)

                }

            }

        }

    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.proveedor.delegate = self
        
        self.proveedor.dataSource = self
        
        toApp(self)
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @IBAction func toApp(_ sender: Any) {
        
        load(isTest: false){ (handler: Bool) in
        }
        
    }
    
    @IBAction func registrarProveedor(_sender: Any){
        
        registrarProveedor(isTest: false)
        
    }
    
    func registrarProveedor(isTest: Bool) {

        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]

        if !nombre.hasText{

            return

        }

        let nombrestr = nombre.text!

        let dirstr = direccion.text!

        let numstr = telefono.text!.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!

        let num2str = telefono2.text!.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!

        

        let idCategoria = isTest ? 1: proveedores[proveedor.selectedRow(inComponent: 0)]["idCategoriaProveedor"] as! Int;

        

        let params: [String: Any] = [

            "nombre" : nombrestr,

            "direccion" : dirstr,

            "telefono1" : Int(numstr) as Any,

            "telefono2" : Int(num2str) as Any,

            "disponible" : !isTest ? 2:1,

            "idsCategoriaProveedor": [Int(idCategoria) as Any]

        ]


        AF.request(urlProveedores, method: .post, parameters: params,encoding: JSONEncoding.default,headers: header).responseJSON  { response in
            
            if let json = response.value {
            
                print("JSON: \(json)") // serialized json response after post
                
            }
            
            if response.response?.statusCode == 200{
                
                self.navigationController?.popViewController(animated: true)
            }
            
        }
        
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return proveedores.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return proveedores[row]["nombre"] as? String
    }
    
}


