//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import Charts

class BalanceViewController: UIViewController {
    let players = ["Ventas", "Compras"]
    var goals = [Float]()
    
    var unavailable = [[String:AnyObject]]()
    var unavailable2 = [[String:AnyObject]]()
    var compras = [[String:AnyObject]]()
    var ventas = [[String:AnyObject]]()
    var urlCompras = "https://groovy-momentum-253317.appspot.com/compras/"
    var urlVentas = "https://groovy-momentum-253317.appspot.com/ventas/"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    
    @IBOutlet weak var fechaInicio: UIDatePicker!
    @IBOutlet weak var fechaFinal: UIDatePicker!
    @IBOutlet weak var balance: UILabel!
    @IBOutlet weak var totalInvertido: UILabel!
    @IBOutlet weak var ganancia: UILabel!
    @IBOutlet weak var pieChartView: PieChartView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        load()
        customizeChart(dataPoints: players, values: goals.map{ Double($0) })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        load()
    }
    
    @IBAction func reloadData(_ sender: Any) {
        load()
    }
    
    func customizeChart(dataPoints: [String], values: [Double]) {
        if dataPoints.count != values.count {
            return
        }
      // 1. Set ChartDataEntry
      var dataEntries: [ChartDataEntry] = []
      for i in 0..<dataPoints.count {
        let dataEntry = PieChartDataEntry(value: values[i], label: dataPoints[i], data: dataPoints[i] as AnyObject)
        dataEntries.append(dataEntry)
      }
      // 2. Set ChartDataSet
        let pieChartDataSet = PieChartDataSet(entries: dataEntries, label: nil)
      pieChartDataSet.colors = colorsOfCharts(numbersOfColor: dataPoints.count)
      // 3. Set ChartData
      let pieChartData = PieChartData(dataSet: pieChartDataSet)
      let format = NumberFormatter()
      format.numberStyle = .none
      let formatter = DefaultValueFormatter(formatter: format)
      pieChartData.setValueFormatter(formatter)
      // 4. Assign it to the chart’s data
      pieChartView.data = pieChartData
    }
    
    private func colorsOfCharts(numbersOfColor: Int) -> [UIColor] {
      var colors: [UIColor] = []
      for _ in 0..<numbersOfColor {
        let red = Double(arc4random_uniform(256))
        let green = Double(arc4random_uniform(256))
        let blue = Double(arc4random_uniform(256))
        let color = UIColor(red: CGFloat(red/255), green: CGFloat(green/255), blue: CGFloat(blue/255), alpha: 1)
        colors.append(color)
      }
      return colors
    }
    
    @IBAction func reload() {
        var sumVentas: Float = 0
        var sumCompras: Float = 0
        
        for z in compras {
            sumVentas += Float(truncating: z["total"]! as! NSNumber)
        }
        for z in ventas {
            sumCompras += Float(truncating: z["total"]! as! NSNumber)
        }
        totalInvertido.text = String(sumVentas)
        balance.text = String(sumCompras-sumVentas)
        ganancia.text = balance.text
        goals.append(sumCompras)
        goals.append(sumVentas)
        pieChartView.data?.notifyDataChanged()
        pieChartView.notifyDataSetChanged()
        customizeChart(dataPoints: players, values: goals.map{ Double($0) })
        balance.textColor = sumCompras > sumVentas ? .green : .red
    }
    
    @IBAction func load() {
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        self.unavailable.removeAll()
        self.unavailable2.removeAll()
        AF.request(urlVentas,headers: header).responseJSON { (responseData) -> Void in
            if((responseData.value) != nil) {
                let swiftyJsonVar = JSON(responseData.value!)
                if let resData = swiftyJsonVar.arrayObject {
                    self.ventas = resData as! [[String:AnyObject]]
                    //Filter data
                    for item in self.ventas {
                        let date = item["fecha"] as! String
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        let currDate = dateFormatter.date(from:String(date.prefix(upTo: date.index(date.startIndex,offsetBy: 10))))!
                        if currDate < self.fechaInicio.date || currDate > self.fechaFinal.date || Int(truncating: item["disponible"] as! NSNumber) != 2{
                            self.unavailable.append(item)
                        }
                        
                    }
                    for item in self.unavailable{
                        let index = self.ventas.firstIndex(where: { dictionary in
                          let value = dictionary["idVenta"] as! Int
                          return value == item["idVenta"] as! Int
                        })
                        if index != nil {
                            self.ventas.remove(at: index!)
                        }
                    }
                    AF.request(self.urlCompras,headers: header).responseJSON{ (response) -> Void in
                        if((response.value) != nil){
                            let json = JSON(response.value!)
                            if let res = json.arrayObject{
                                self.compras = res as! [[String:AnyObject]]
                                //Filter
                                for item in self.compras {
                                    let date = item["fecha"] as! String
                                    let dateFormatter = DateFormatter()
                                    dateFormatter.dateFormat = "yyyy-MM-dd"
                                    let currDate = dateFormatter.date(from:String(date.prefix(upTo: date.index(date.startIndex,offsetBy: 10))))!
                                    if currDate < self.fechaInicio.date || currDate > self.fechaFinal.date || Int(truncating: item["disponible"] as! NSNumber) != 2{
                                        self.unavailable2.append(item)
                                    }
                                    
                                }
                                for item in self.unavailable2{
                                    let index = self.compras.firstIndex(where: { dictionary in
                                      let value = dictionary["idCompra"] as! Int
                                      return value == item["idCompra"] as! Int
                                    })
                                    if index != nil {
                                        self.compras.remove(at: index!)
                                    }
                                }
                                self.reload()
                            }
                        }
                    }
                    
                }
            }
        }
    }
    
    
}

