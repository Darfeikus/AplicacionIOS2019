//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBAction func goSettings1(_ sender: Any) {performSegue(withIdentifier: "goSettings", sender: self)}
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

