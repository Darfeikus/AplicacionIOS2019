//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class IniciarSesionViewController: UIViewController {
    
    @IBOutlet var usuario: UITextField! = UITextField()
    @IBOutlet var password: UITextField! = UITextField()
    var apiurl = "https://groovy-momentum-253317.appspot.com/login/"
    var todos = [[String:AnyObject]]()
       
    func toAplicacion(isTest: Bool,completionHanlder: @escaping(_ status:Bool)->Void) {     
        
        let params: [String: Any] = [
        
            "usuario": usuario.text as Any,
            
            "password": password.text as Any
            
        ]
        
        AF.request(apiurl, method: .post, parameters: params,encoding: JSONEncoding.default).responseJSON  { response in
        
            if let json = response.value {
            
                let swiftyJsonVar = JSON([json])
                
                if let resData = swiftyJsonVar.arrayObject {
                
                    self.todos = resData as! [[String:AnyObject]]
                    
                    if response.response?.statusCode == 200{
                    
                        let defaults = UserDefaults.standard
                        
                        defaults.set(self.todos[0]["token"], forKey:"token")
                        
                        completionHanlder(true)
                        
                        if isTest{
                        
                            return
                            
                        }
                        
                        self.performSegue(withIdentifier: "toAplicacion", sender: self)
                        
                    }
                    
                    print("failure")
                    
                    completionHanlder(true)
                    
                }
                
            }
            
        }
        
    }

    
    @IBAction func toApp(_ sender: Any) {
        toAplicacion(isTest: false){ (handler: Bool) in
        }
    }
    
    @IBAction func toRegistro(_ sender: Any) {
        performSegue(withIdentifier: "toRegistro", sender: self)
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let tap: UITapGestureRecognizer =
            UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        
        view.addGestureRecognizer(tap)
    }
    
}

