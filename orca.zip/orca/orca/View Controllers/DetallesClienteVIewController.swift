//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class DetallesClienteViewController: UIViewController {

    var nombres = String()
    var direccions = String()
    var telefono1s = String()
    var telefono2s = String()
    var creados = String()
    var updates = String()

    @IBOutlet var nombre: UILabel! = UILabel()
    @IBOutlet var direccion: UILabel! = UILabel()
    @IBOutlet var telefono1: UILabel! = UILabel()
    @IBOutlet var telefono2: UILabel! = UILabel()
    @IBOutlet var creado: UILabel! = UILabel()
    @IBOutlet var update: UILabel! = UILabel()
    
    override func viewDidLoad() {

        super.viewDidLoad()
        
        nombre.text = nombres
        
        direccion.text = direccions
        
        telefono1.text = telefono1s
        
        telefono2.text = telefono2s
        
        creado.text = creados
        
        update.text = updates
        
    }

}
