//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class RegistrarUsuarioViewController: UIViewController {
    
    @IBOutlet var usuario: UITextField! = UITextField()
    @IBOutlet var contrasena: UITextField! = UITextField()
    @IBOutlet var nombre: UITextField! = UITextField()
    @IBOutlet var apellidos: UITextField! = UITextField()
    
    var apiurl = "https://groovy-momentum-253317.appspot.com/usuarios/"
    
    @IBAction func toIniciar(_ sender: Any) {performSegue(withIdentifier: "toInicio", sender: self)}
    
    func toAplicacion(isTest: Bool,completionHanlder: @escaping(_ status:Bool)->Void) {

        let params: [String: Any] = [
        
            "usuario": usuario.text as Any,
            
            "password": contrasena.text as Any,
            
            "nombre": nombre.text as Any,
            
            "apellidos": apellidos.text as Any,
            
            "disponible": "2",
            
            "idRole": 3
            
        ]
        
        AF.request(apiurl, method: .post, parameters: params, encoding: JSONEncoding.default).responseJSON  { response in
        
            if response.response?.statusCode == 201 {
            
                completionHanlder(true)
                
                if isTest{
                
                    return
                    
                }
                
                self.performSegue(withIdentifier: "toInicio", sender: self)
                
            }
            
            completionHanlder(true)
            
        }
        
    }

    
    @IBAction func toApp(_ sender: Any) {
        toAplicacion(isTest: false){ (handler: Bool) in
        }
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
        
    }
    
}

