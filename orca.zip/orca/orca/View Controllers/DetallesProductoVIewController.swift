//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class DetallesProductoViewController: UIViewController {

    var nombres = String()
    var descripcions = String()
    var cantidads = String()
    var utilidads = String()
    var creados = String()
    var updates = String()
    var precios = String()
    var costos = String()

    @IBOutlet var nombre: UILabel! = UILabel()
    @IBOutlet var descripcion: UILabel! = UILabel()
    @IBOutlet var cantidad: UILabel! = UILabel()
    @IBOutlet var utilidad: UILabel! = UILabel()
    @IBOutlet var creado: UILabel! = UILabel()
    @IBOutlet var update: UILabel! = UILabel()
    @IBOutlet var precio: UILabel! = UILabel()
    @IBOutlet var costo: UILabel! = UILabel()
    
    override func viewDidLoad() {

        super.viewDidLoad()
        
        nombre.text = nombres
        
        descripcion.text = descripcions
        
        cantidad.text = cantidads
        
        utilidad.text = utilidads
        
        creado.text = creados
        
        update.text = updates
        
        precio.text = precios
        
        costo.text = costos
        
    }

    
}
