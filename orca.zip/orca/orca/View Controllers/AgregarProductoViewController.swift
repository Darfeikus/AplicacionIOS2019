//
//  SecondViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class AgregarProductoViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var productos = [[String:AnyObject]]()
    var unavailable = [[String:AnyObject]]()
    var misProductos = [[String:AnyObject]]()
    var urlProductos = "https://groovy-momentum-253317.appspot.com/productos"
    var edit = 0
    var modify = 0
    var row = 0;
    var indexProducto = 0;
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    var precioOr = Float()
    
    @IBOutlet var producto: UIPickerView! = UIPickerView()
    @IBOutlet var cantidad: UITextField! = UITextField()
    @IBOutlet var precio: UITextField! = UITextField()
    @IBOutlet var total: UILabel! = UILabel()
    
    @IBAction func toRegistro(_ sender: Any) {
        if edit == 0{
            let a = self.navigationController?.viewControllers[1] as! RegistroVentaViewController
            a.misProductos = misProductos
            self.navigationController?.popViewController(animated: true)
        }
        else{
            let a = self.navigationController?.viewControllers[1] as! DetallesVentaViewController
            a.productos = misProductos
            a.modify = 0
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        updateTotal()
    }
    
    func updatePrecioOr(_ sender: Any){
        if productos.count == 0 {
            return
        }
        let i = producto.selectedRow(inComponent: 0)
        
        producto.selectRow(i, inComponent: 0, animated: true)
        
        precioOr = Float(truncating: productos[i]["precio"] as! NSNumber)
        
        precio.text = String(precioOr)
        
        updateTotal()
    }
    
    @IBAction func load(isTest: Bool,completionHandler: @escaping(_ status:Bool)->Void) {

        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]

        let params = ["accessKey":"123"]

        AF.request(urlProductos,parameters: params,headers: header).responseJSON { (responseData) -> Void in

            if((responseData.value) != nil) {

                let swiftyJsonVar = JSON(responseData.value!)

                if let resData = swiftyJsonVar.arrayObject {

                    self.productos = resData as! [[String:AnyObject]]

                }

                for item in self.productos {

                    if Int(truncating: item["disponible"] as! NSNumber) != 2{

                        self.unavailable.append(item)

                    }

                    

                }

                for item in self.unavailable{
                    let index = self.productos.firstIndex(where: { dictionary in
                      let value = dictionary["idProducto"] as! Int
                      return value == item["idProducto"] as! Int
                    })
                    if index != nil {
                        self.productos.remove(at: index!)
                    }
                    CATransaction.begin()
                    CATransaction.setCompletionBlock {
                        completionHandler(true)
                    }
                    self.producto.reloadAllComponents()
                    CATransaction.commit()
                }
                
                CATransaction.begin()
                
                CATransaction.setCompletionBlock {
                
                    completionHandler(true)
                    
                }
                
                self.producto.reloadAllComponents()
                
                self.updatePrecioOr(self)
                
                CATransaction.commit()
                
            }
            
        }
        
    }
    
   @IBAction func loadValues(isTest: Bool,completionHandler: @escaping(_ status:Bool)->Void) {

        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]

        let params = ["accessKey":"123"]

        print(misProductos)

        print(self.row)

        let currentProd = self.misProductos[self.row]

        self.cantidad.text = "\(Int(truncating: currentProd["cantidad"] as! NSNumber))"

        AF.request(urlProductos,parameters: params,headers: header).responseJSON { (responseData) -> Void in

            if((responseData.value) != nil) {

                let swiftyJsonVar = JSON(responseData.value!)

                if let resData = swiftyJsonVar.arrayObject {

                    self.productos = resData as! [[String:AnyObject]]

                    var index = 0

                    for prod in self.productos {

                        if prod["idProducto"] as! Int == currentProd["idProducto"] as! Int{

                            self.indexProducto = index

                            break

                        }

                        index+=1

                    }

                }

                for item in self.productos {

                    if Int(truncating: item["disponible"] as! NSNumber) != 2{

                        self.unavailable.append(item)

                    }

                }

                for item in self.unavailable{
                    let index = self.productos.firstIndex(where: { dictionary in
                      let value = dictionary["idProducto"] as! Int
                      return value == item["idProducto"] as! Int
                    })
                    if index != nil {
                        self.productos.remove(at: index!)
                    }
                    DispatchQueue.main.async{
                        self.producto.reloadAllComponents()
                    }
                }

                DispatchQueue.main.async{

                    self.producto.reloadAllComponents()

                    self.producto.selectRow(self.indexProducto, inComponent: 0, animated: true)

                    self.updatePrecioOr(self)
                    
                    completionHandler(true)

                }

            }

        }

    }

    
    @IBAction func registrar(_ sender: Any) {
        updateTotal()
        let index = producto.selectedRow(inComponent: 0)
        let currentProd = productos[index]
        let a = Float(cantidad.text ?? "0") ?? 0
        let b = Float(precio.text ?? "0") ?? 0
        let newProd: [String:Any] = [
            "idProducto": currentProd["idProducto"] as! Int,
            "nombre": currentProd["nombre"] as! String,
            "cantidad": Int(cantidad.text!) as Any,
            "precio": a*b as Any,
        ]
        misProductos.append(newProd as [String : AnyObject])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.producto.delegate = self
        
        self.producto.dataSource = self
        
        self.cantidad.text = "1"
        
        if modify == 0{
            
            toApp(self)
            
        }
        else{
            
            toApp2(self)
            
            misProductos.remove(at: row)
            
        }
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @IBAction func toApp(_ sender: Any) {
        
        load(isTest: false){ (handler: Bool) in
        }
        
    }
    
    @IBAction func toApp2(_ sender: Any) {
        
        loadValues(isTest: false){ (handler: Bool) in
        }
        
    }
    
    @objc func dismissKeyboard() {
        updateTotal()
        view.endEditing(true)
    }
    
    func updateTotal(){
        
        let a = Float(cantidad.text ?? "0") ?? 0
        
        let b = Float(precio.text ?? "0") ?? 0
        
        total.text = "$\(String(a*b))"
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return productos.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return productos[row]["nombre"] as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        updatePrecioOr(self)
    }
}

