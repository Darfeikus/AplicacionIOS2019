//
//  FirstViewController.swift
//  orca
//
//  Created by Oscar Barbosa Aquino on 9/26/19.
//  Copyright © 2019 Oscar Barbosa Aquino. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ProveedoresViewController: UIViewController {

    var apiurl = "https://groovy-momentum-253317.appspot.com/proveedores"
    var accessKey = UserDefaults.standard.string(forKey: "token") ?? ""
    var todos = [[String:AnyObject]]()
    var unavailable = [[String:AnyObject]]()
    var nombres = String()
    var direccions = String()
    var telefono1s = String()
    var telefono2s = String()
    var creados = String()
    var updates = String()
    
    @IBOutlet var tableView: UITableView! = UITableView()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier != "toDetalles"){
            return
        }
        let destinationVC = segue.destination as! DetallesClienteViewController
        destinationVC.nombres = self.nombres
        destinationVC.direccions = self.direccions
        destinationVC.telefono1s = self.telefono1s
        destinationVC.telefono2s = self.telefono2s
        destinationVC.creados = self.creados
        destinationVC.updates = self.updates
    }
    
    override func viewWillAppear(_ animated: Bool) {
        toApp(self)
    }
    
    func load(isTest: Bool,completionHandler: @escaping(_ status:Bool)->Void) {
        
        let header: HTTPHeaders = ["Authorization": "Bearer \(accessKey)"]
        let params = ["accessKey":"123"]
        
        print(self.accessKey)
        AF.request(apiurl,parameters: params,headers: header).responseJSON { (responseData) -> Void in
            
            if((responseData.value) != nil) {
                print(responseData.value!)
                
                let swiftyJsonVar = JSON(responseData.value!)
                
                if let resData = swiftyJsonVar.arrayObject {
                    
                    self.todos = resData as! [[String:AnyObject]]
                    
                    for item in self.todos {
                        
                        if Int(truncating: item["disponible"] as! NSNumber) != 2 {
                            self.unavailable.append(item)
                        }
                        
                    }
                    for item in self.unavailable{
                        
                        let index = self.todos.firstIndex(where: { dictionary in
                        
                            let value = dictionary["idProveedor"] as! Int
                          
                            return value == item["idProveedor"] as! Int
                        })
                        if index != nil {
                            self.todos.remove(at: index!)
                        }
                    }
                }
                CATransaction.begin()
                
                CATransaction.setCompletionBlock {
                    
                    completionHandler(true)
                    
                }
                
                self.tableView.reloadData()
                
                CATransaction.commit()
            }
        }
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        tableView.dataSource = self
        
        tableView.delegate = self
        
        toApp(self)
        
    }
    
    @IBAction func toApp(_ sender: Any) {
        load(isTest: false){ (handler: Bool) in
        }
    }
    
    @IBAction func toCliente(_ sender: Any) {
        performSegue(withIdentifier: "toCliente", sender: self)
    }
    
    @IBAction func toTipoCliente(_ sender: Any) {
        performSegue(withIdentifier: "toTipoCliente", sender: self)
    }
}
extension ProveedoresViewController:UITableViewDataSource, UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var x = 0
        if todos[indexPath.row]["telefono1"] as? Int ?? 0 != 0{
            x = todos[indexPath.row]["telefono1"] as! Int
        }
        let disp = todos[indexPath.row]["disponible"] as! Int
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",for: indexPath)
        if disp==2{
            cell.textLabel?.text = todos[indexPath.row]["nombre"] as? String
            cell.detailTextLabel?.text = "Telefono: \(String(x))"
        }
        else{
            cell.isHidden = true
        }
        return cell
     }
     

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return todos.count
     }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let editAction = UIContextualAction(style: .normal, title: "Detalles"){ (action,view,completionHandler) in
            self.nombres = self.todos[indexPath.row]["nombre"] as! String
            self.direccions = self.todos[indexPath.row]["direccion"] as! String
            self.telefono1s = "\(self.todos[indexPath.row]["telefono1"] as? Int ?? 0)"
            self.telefono2s = "\(self.todos[indexPath.row]["telefono2"] as? Int ?? 0)"
            self.creados = self.todos[indexPath.row]["createdAt"] as! String
            self.updates = self.todos[indexPath.row]["updatedAt"] as! String
            self.creados = String(self.creados.prefix(10))
            self.updates = String(self.updates.prefix(10))
            self.performSegue(withIdentifier: "toDetalles", sender: self)
            completionHandler(true)
        }
        editAction.backgroundColor = UIColor.blue
        return UISwipeActionsConfiguration(actions: [editAction])
    }
    
}
